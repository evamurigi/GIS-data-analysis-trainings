Download all files in this repository and place in a single folder on your computer. 
