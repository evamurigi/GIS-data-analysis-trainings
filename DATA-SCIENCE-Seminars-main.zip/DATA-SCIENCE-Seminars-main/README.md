# CIFOR-ICRAF Data Science Seminars
This repository contains each seminar as a subfolder named by date. Kindly click on the ones you would like to explore, or clone the repository to your own computer. 
